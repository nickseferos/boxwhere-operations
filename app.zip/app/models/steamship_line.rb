class SteamshipLine < ApplicationRecord
end
