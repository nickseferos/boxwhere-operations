class Gang < ApplicationRecord
  belongs_to :shift
end
