class LongshoreReg < ApplicationRecord
end
