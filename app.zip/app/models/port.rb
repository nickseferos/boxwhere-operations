class Port < ApplicationRecord
  belongs_to :state
end
