class Country < ApplicationRecord
end
