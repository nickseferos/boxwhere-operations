class Terminal < ApplicationRecord
  belongs_to :port
end
