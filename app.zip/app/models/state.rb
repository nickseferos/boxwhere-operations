class State < ApplicationRecord
  belongs_to :country
end
