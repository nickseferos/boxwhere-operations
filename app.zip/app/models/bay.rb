class Bay < ApplicationRecord
  belongs_to :vessel
end
