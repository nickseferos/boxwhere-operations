module VoyagesHelper
end
